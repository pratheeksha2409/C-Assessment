﻿using SampleCoreMvcApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SampleCoreMvcApp.Controllers
{
    public class CustomerController : Controller
    {
        public ViewResult AllCustomers()
        {
            var context = new LnTTrainingEntities();
            var model = context.CustoTables.ToArray();
            return View(model);
        }
        public ViewResult Update(string id)
        {
            int custId = int.Parse(id);
            var context = new LnTTrainingEntities();
            var model = context.CustoTables.FirstOrDefault((c) => c.CustID == custId);
            return View(model);

        }
        [HttpPost]
        public ActionResult Update(CustoTable cust)
        {
            var context = new LnTTrainingEntities();
            var model = context.CustoTables.FirstOrDefault((c) => c.CustID == cust.CustID);
            model.CustName = cust.CustName;
            model.CustAddress = cust.CustAddress;
            model.CustNumber = cust.CustNumber;
            context.SaveChanges();
            return RedirectToAction("AllCustomers");
        }

        public ViewResult AddNewCustomer()
        {
            var model = new CustoTable();
            return View(model);
        }
        [HttpPost]
        public ActionResult AddNewCustomer(CustoTable cust)
        {
            var context = new LnTTrainingEntities();
            context.CustoTables.Add(cust);
            context.SaveChanges();
            return RedirectToAction("AllCustomers");
        }
        public ViewResult Delete(string id)
        {
            var custId = int.Parse(id);
            var context = new LnTTrainingEntities();
            var model = context.CustoTables.FirstOrDefault((c) => c.CustID == custId);
            return View(model);
        }
        [HttpPost]
        public ActionResult Delete(string id, string conformbutton)
        {
            int custId = int.Parse(id);
            var context = new LnTTrainingEntities();
            var model = context.CustoTables.FirstOrDefault((c) => c.CustID == custId);
            context.CustoTables.Remove(model);
            context.SaveChanges();
            return RedirectToAction("AllCustomers");
        }
    }
}
